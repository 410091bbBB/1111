#include "Recorder.h"

#include "ll/api/event/Listener.h"
#include "ll/api/event/player/PlayerChatEvent.h"
#include "ll/api/memory/Hook.h"
#include "ll/api/mod/NativeMod.h"
#include "ll/api/service/Bedrock.h"

#include "mc/deps/core/utility/BinaryStream.h"
#include "mc/network/MinecraftPacketIds.h"
#include "mc/network/Packet.h"
#include "mc/network/ServerNetworkHandler.h"
#include "mc/server/ServerPlayer.h"
#include "mc/world/actor/player/Player.h"

#include <algorithm>
#include <chrono>
#include <cctype>
#include <cstring>
#include <ctime>
#include <fstream>
#include <utility>

namespace hf_replay {

// ============================================================
//  拦包钩子：所有 客户端→服务端 的包都会经过这里。
//  只在「录制中」才做判断，平时一次布尔读，零开销。
// ============================================================
LL_TYPE_INSTANCE_HOOK(
    HfRecorderHook,
    ll::memory::HookPriority::Normal,
    ServerNetworkHandler,
    &ServerNetworkHandler::$handle,
    void,
    ::NetworkIdentifier const& source,
    ::Packet const&            packet
) {
    hf_replay::Recorder::getInstance().tryCapture(source, packet);
    origin(source, packet);
}

Recorder& Recorder::getInstance() {
    static Recorder inst;
    return inst;
}

void Recorder::installHooks() { HfRecorderHook::hook(); }
void Recorder::uninstallHooks() {
    if (HfRecorderHook::isHooked()) HfRecorderHook::unhook();
}

std::filesystem::path Recorder::recordsDir() {
    return getSelf().getModDir() / "records";
}

std::filesystem::path Recorder::dataDir() const {
    return recordsDir();
}

static uint64_t nowMs() {
    return (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

std::string Recorder::start(Player* target) {
    if (mRecording) return "当前正在录制，先停止再开始";
    if (!target) return "找不到该玩家";

    mTargetName = target->getName();
    mTarget     = target;
    mTargetNid  = target->getNetworkIdentifier();
    mPackets.clear();
    mChats.clear();
    mStartMs = nowMs();

    auto const& pos = target->getPosition();
    mStartPosX  = pos.x;
    mStartPosY  = pos.y;
    mStartPosZ  = pos.z;
    mStartDimId = static_cast<int32_t>(target->getDimensionId());

    mRecording = true;
    return "";
}

StopResult Recorder::stopAndSave() {
    StopResult res;
    if (!mRecording) {
        res.msg = "当前没有在录制";
        return res;
    }
    mRecording = false;

    size_t packetCount = mPackets.size();
    size_t chatCount   = mChats.size();
    if (packetCount == 0) {
        mTarget = nullptr;
        res.msg = "录制为空（没有捕捉到任何行为），已丢弃";
        return res;
    }

    std::time_t t = std::time(nullptr);
    std::tm     tm{};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char suffix[32];
    std::strftime(suffix, sizeof(suffix), "%m%d_%H%M%S", &tm);

    std::string safe;
    for (char c : mTargetName) {
        if (std::isalnum((unsigned char)c) || c == '_' || c == '-') safe += c;
    }
    if (safe.empty()) safe = "player";
    std::string fname = safe + "_" + suffix + ".hfr";

    std::error_code ec;
    std::filesystem::create_directories(dataDir(), ec);
    std::filesystem::path path = dataDir() / fname;

    RecordFileHeader header{};
    std::memcpy(header.magic, "HFREPLAY1", 8);
    header.version     = 1;
    header.packetCount = (uint32_t)packetCount;
    header.chatCount   = (uint32_t)chatCount;
    header.startPosX   = mStartPosX;
    header.startPosY   = mStartPosY;
    header.startPosZ   = mStartPosZ;
    header.startDimId  = mStartDimId;
    header.durationMs  = mPackets.back().first.timeMs;
    std::strncpy(header.targetName, mTargetName.c_str(), sizeof(header.targetName) - 1);

    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) {
        res.msg = "录制文件写入失败";
        return res;
    }

    out.write((char const*)&header, sizeof(header));

    // 按时间序交错写入：包 + 聊天
    size_t chatIdx = 0;
    for (auto const& [h, bytes] : mPackets) {
        while (chatIdx < mChats.size() && mChats[chatIdx].first.timeMs <= h.timeMs) {
            auto const& [ch, text] = mChats[chatIdx];
            RecordPacketEntry ce = ch; // entryType=2, packetId=0, timeMs 已就绪
            ce.dataLen = (uint32_t)text.size();
            out.write((char const*)&ce, sizeof(ce));
            out.write(text.data(), ce.dataLen);
            chatIdx++;
        }
        RecordPacketEntry pe = h; // entryType=1, packetId, timeMs 已就绪
        out.write((char const*)&pe, sizeof(pe));
        out.write((char const*)bytes.data(), (std::streamsize)bytes.size());
    }
    while (chatIdx < mChats.size()) {
        auto const& [ch, text] = mChats[chatIdx];
        RecordPacketEntry ce = ch;
        ce.dataLen = (uint32_t)text.size();
        out.write((char const*)&ce, sizeof(ce));
        out.write(text.data(), ce.dataLen);
        chatIdx++;
    }
    out.close();

    mTarget = nullptr;
    res.ok  = true;
    res.msg = path.string();
    return res;
}

void Recorder::tryCapture(::NetworkIdentifier const& nid, ::Packet const& packet) {
    if (!mRecording) return;
    if (!(nid == mTargetNid)) return;

    auto id = (uint32_t)packet.getId();
    switch (id) {
    case (uint32_t)::MinecraftPacketIds::PlayerAuthInput:
    case (uint32_t)::MinecraftPacketIds::Interact:
    case (uint32_t)::MinecraftPacketIds::Animate:
    case (uint32_t)::MinecraftPacketIds::MobEquipment:
        break;
    default:
        return;
    }

    try {
        ::BinaryStream stream;
        packet.write(stream); // 包自己序列化自己，一字不改

        RecordPacketEntry h{};
        h.entryType = 1;
        h.packetId  = id;
        h.timeMs    = nowMs() - mStartMs;
        auto const& buf = stream.mBuffer; // ← 编译报错就改成 stream.mBuffer.get()
        std::vector<uint8_t> bytes(buf.begin(), buf.end());
        h.dataLen = (uint32_t)bytes.size();
        mPackets.emplace_back(h, std::move(bytes));
    } catch (std::exception const& e) {
        getSelf().getLogger().warn("录制序列化失败 id={}: {}", id, e.what());
    } catch (...) {
        getSelf().getLogger().warn("录制序列化失败 id={}", id);
    }
}

void Recorder::tryCaptureChat(Player* player, std::string const& message) {
    if (!mRecording) return;
    if (!player || player->getName() != mTargetName) return;
    RecordPacketEntry h{};
    h.entryType = 2;
    h.packetId  = 0;
    h.timeMs    = nowMs() - mStartMs;
    h.dataLen   = (uint32_t)message.size();
    mChats.emplace_back(h, message);
}

} // namespace hf_replay
