#include "Replayer.h"

#include "ll/api/chrono/GameChrono.h"
#include "ll/api/mod/NativeMod.h"
#include "ll/api/service/Bedrock.h"
#include "ll/api/thread/ServerThreadExecutor.h"

#include "mc/deps/core/math/Vec3.h"
#include "mc/deps/core/utility/BinaryStream.h"
#include "mc/network/MinecraftPacketIds.h"
#include "mc/network/Packet.h"
#include "mc/network/ServerNetworkHandler.h"
#include "mc/network/packet/AnimatePacket.h"
#include "mc/network/packet/InteractPacket.h"
#include "mc/network/packet/MobEquipmentPacket.h"
#include "mc/network/packet/PlayerAuthInputPacket.h"
#include "mc/network/packet/TextPacket.h"
#include "mc/server/SimulatedPlayer.h"
#include "mc/server/ServerPlayer.h"
#include "mc/world/actor/player/Player.h"

#include <chrono>
#include <cstring>
#include <fstream>
#include <memory>

namespace hf_replay {

Replayer& Replayer::getInstance() {
    static Replayer inst;
    return inst;
}

static uint64_t nowMs() {
    return (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

// 按协议号重建包对象（这些类型都能默认构造，_read 会把字节灌回去）
static std::unique_ptr<::Packet> makePacketById(uint32_t id) {
    switch (id) {
    case (uint32_t)::MinecraftPacketIds::PlayerAuthInput:
        return std::make_unique<::PlayerAuthInputPacket>();
    case (uint32_t)::MinecraftPacketIds::Interact:
        return std::make_unique<::InteractPacket>();
    case (uint32_t)::MinecraftPacketIds::Animate:
        return std::make_unique<::AnimatePacket>();
    case (uint32_t)::MinecraftPacketIds::MobEquipment:
        return std::make_unique<::MobEquipmentPacket>();
    default:
        return nullptr;
    }
}

std::string Replayer::start(std::filesystem::path const& file) {
    if (mPlaying) return "当前已有回放在进行";

    std::ifstream in(file, std::ios::binary);
    if (!in) return "录制文件读取失败";

    RecordFileHeader h{};
    if (!in.read((char*)&h, sizeof(h))) return "录制文件损坏";
    if (std::memcmp(h.magic, "HFREPLAY1", 8) != 0) return "这不是有效的录制文件";

    mEntries.clear();
    uint64_t count = (uint64_t)h.packetCount + (uint64_t)h.chatCount;
    for (uint64_t i = 0; i < count; ++i) {
        RecordPacketEntry e{};
        if (!in.read((char*)&e, sizeof(e))) break;
        ReplayEntry re;
        re.entryType = e.entryType;
        re.packetId  = e.packetId;
        re.timeMs    = e.timeMs;
        re.data.resize(e.dataLen);
        if (e.dataLen) in.read(re.data.data(), e.dataLen);
        mEntries.push_back(std::move(re));
    }
    if (mEntries.empty()) return "录制内容为空";

    // 假人从录制起点的位置登场，这样第一帧输入就是对的
    mBotName = "HF_" + file.stem().string();
    auto* handler = ll::service::getServerNetworkHandler();
    if (!handler) return "服务端网络处理器不可用";

    ::Vec3 spawnPos{h.startPosX, h.startPosY, h.startPosZ};
    auto*  sp = ::SimulatedPlayer::create(mBotName, spawnPos, h.startDimId);
    if (!sp) return "假人创建失败";

    mBot   = sp;
    mBotNid = sp->getNetworkIdentifier();
    mNext  = 0;
    mPlayedCount = 0;
    mStartMs = nowMs();
    mCurrentFile = file.filename().string();
    mPlaying = true;

    // 等 5 tick 让假人完全进入世界，再开始吐第一包
    scheduleNext(5);

    getSelf().getLogger().info(
        "回放开始: {} ({} 条记录, {} ms)", mCurrentFile, mEntries.size(), h.durationMs);
    return "";
}

void Replayer::scheduleNext(int delayTicks) {
    ll::thread::ServerThreadExecutor::getDefault().executeAfter(
        [this]() { step(); }, ll::chrono::ticks{delayTicks});
}

void Replayer::step() {
    if (!mPlaying) return;

    auto* handler = ll::service::getServerNetworkHandler();
    if (!handler || !mBot) {
        finish(false);
        return;
    }

    uint64_t const elapsed = nowMs() - mStartMs;

    try {
        while (mNext < mEntries.size() && mEntries[mNext].timeMs <= elapsed) {
            ReplayEntry const& e = mEntries[mNext++];

            if (e.entryType == 2) {
                // 聊天：照 LSE talkAs 的方式走完整聊天管线
                ::TextPacket pkt = ::TextPacket::createChat(
                    mBotName, e.data, {}, mBot->getXuid(), {});
                ll::service::getLevel()->forEachPlayer(
                    [&pkt](::Player const& pl) {
                        pl.sendNetworkPacket(pkt);
                        return true;
                    });
                continue;
            }

            auto pkt = makePacketById(e.packetId);
            if (!pkt) continue;

            ::ReadOnlyBinaryStream ros(e.data, false); // ← 报错就换 (std::string_view, false) 重载
            pkt->_read(ros);                           // 原始字节原样灌回包对象
            handler->handle(mBotNid, *pkt);            // 服务端把假人当真玩家处理
            ++mPlayedCount;
        }
    } catch (std::exception const& ex) {
        getSelf().getLogger().error("回放异常，已终止: {}", ex.what());
        finish(false);
        return;
    } catch (...) {
        getSelf().getLogger().error("回放异常，已终止");
        finish(false);
        return;
    }

    if (mNext >= mEntries.size()) {
        finish(true);
        return;
    }
    scheduleNext(1); // 下一 tick 继续吐到期的包
}

void Replayer::finish(bool completed) {
    mPlaying = false;
    std::string msg = completed
        ? "§e[回放] §f播放完毕：" + mBotName + " 仍在场，不要了就 /hf 4"
        : "§e[回放] §c播放中断：" + mBotName;
    try {
        ::TextPacket pkt = ::TextPacket::createSystemMessage(msg);
        pkt.sendToClients();
    } catch (...) {}
    getSelf().getLogger().info("回放结束({}) 已重放 {} 条", completed ? "完整" : "中断", mPlayedCount);
}

std::string Replayer::stop(bool removeBot) {
    if (!mPlaying) return "当前没有在回放";
    mPlaying = false; // 排队中的 step 会因 mPlaying=false 直接返回
    if (removeBot) cleanupBot();
    getSelf().getLogger().info("回放被手动停止，已重放 {} 条", mPlayedCount);
    return "";
}

void Replayer::cleanupBot() {
    if (!mBot) return;
    try {
        auto* sp = static_cast<::SimulatedPlayer*>(mBot);
        sp->disconnect();
        sp->remove();
        sp->setGameTestHelper(nullptr);
    } catch (...) {
    }
    mBot = nullptr;
}

} // namespace hf_replay
