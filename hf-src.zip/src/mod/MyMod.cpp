#include "mod/MyMod.h"

#include "../Commands.h"
#include "../Recorder.h"
#include "../Replayer.h"

#include "ll/api/event/EventBus.h"
#include "ll/api/event/ListenerBase.h"
#include "ll/api/event/player/PlayerChatEvent.h"
#include "ll/api/mod/RegisterHelper.h"

namespace hf_replay {

HFReplayMod& HFReplayMod::getInstance() {
    static HFReplayMod instance;
    return instance;
}

bool HFReplayMod::load() {
    getSelf().getLogger().info("假人行为录制回放 正在加载");
    return true;
}

bool HFReplayMod::enable() {
    Recorder::getInstance().installHooks();

    mChatListener = ll::event::Listener<ll::event::PlayerChatEvent>::create(
        [](ll::event::PlayerChatEvent& ev) {
            Recorder::getInstance().tryCaptureChat(&ev.player(), ev.message());
        });

    registerCommands();

    getSelf().getLogger().info(
        "已启用：/hf 1 开始录制 | /hf 2 结束保存 | /hf 3 回放 | /hf 4 停止回放 | /hf 5 列表 | /hf 6 删除");
    return true;
}

bool HFReplayMod::disable() {
    if (mChatListener) {
        ll::event::ListenerBase::removeListener(mChatListener);
        mChatListener = nullptr;
    }
    if (Replayer::getInstance().isPlaying()) Replayer::getInstance().stop(false);
    if (Recorder::getInstance().isRecording()) Recorder::getInstance().stopAndSave();
    Recorder::getInstance().uninstallHooks();
    return true;
}

} // namespace hf_replay

LL_REGISTER_MOD(hf_replay::HFReplayMod, hf_replay::HFReplayMod::getInstance());
