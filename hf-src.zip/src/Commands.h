#pragma once

namespace hf_replay {
void registerCommands();
} // namespace hf_replay
