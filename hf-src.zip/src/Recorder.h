#pragma once

// ============================================================
//  hf-replay / Recorder.h —— 录制层
//
//  架构（一句话）：
//    玩家在服务端的一切行为，本质上是一个每 tick 一条的
//    PlayerAuthInputPacket（协议 ID 144）输入流 + 少量补充包。
//    本层只做一件事：把录制目标的原始输入包【原封不动】存成字节，
//    不解析、不翻译、不理解内容。
//
//  采集白名单（客户端→服务端的"行为"包）：
//    144 PlayerAuthInput  —— 位置/朝向/按键位集/跳/潜行/冲刺/游泳/
//                             滑翔/挖方块/放方块/用物品/物品栏/载具
//    33  Interact          —— 攻击/交互实体
//    40  Animate           —— 挥手
//    47  MobEquipment      —— 切换手持物品
//  聊天不走包：用 PlayerChatEvent 记录原文，回放用 simulateChat。
// ============================================================

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

#include "mc/network/NetworkIdentifier.h"

class Packet;
class Player;

namespace hf_replay {

// 统一记录条目（文件里每条 = 20字节头 + data）
//   entryType = 1 : data 是包体原始字节, packetId 有效
//   entryType = 2 : data 是聊天文本 UTF-8, packetId = 0
struct RecordPacketEntry {
    uint32_t entryType;
    uint32_t packetId;
    uint32_t dataLen;
    uint64_t timeMs;
};

// 录制文件头（纯二进制）
#pragma pack(push, 1)
struct RecordFileHeader {
    char     magic[8];     // "HFREPLAY1"
    uint32_t version;      // 1
    char     targetName[64];
    uint32_t packetCount;  // type=1 条数
    uint32_t chatCount;    // type=2 条数
    float    startPosX;
    float    startPosY;
    float    startPosZ;
    int32_t  startDimId;
    uint64_t durationMs;
};
#pragma pack(pop)

struct StopResult {
    bool        ok = false;
    std::string msg; // ok=true 时是文件路径，否则是错误说明
};

class Recorder {
public:
    static Recorder& getInstance();

    static std::filesystem::path recordsDir(); // 录制文件目录（命令层共用）

    void installHooks();   // enable 时调用
    void uninstallHooks(); // disable 时调用

    // 开始录制某个玩家。返回空串 = 成功，否则为错误信息
    std::string start(Player* target);

    // 停止并保存。StopResult
    StopResult stopAndSave();

    bool    isRecording() const { return mRecording; }
    Player* target() const { return mTarget; }

    // 由网络钩子调用：尝试捕获一个包（非目标/非白名单时直接返回）
    void tryCapture(::NetworkIdentifier const& nid, ::Packet const& packet);

    // 由聊天事件调用
    void tryCaptureChat(Player* player, std::string const& message);

private:
    Recorder() = default;

    bool              mRecording = false;
    Player*           mTarget    = nullptr;
    ::NetworkIdentifier mTargetNid{};
    std::string       mTargetName;
    uint64_t          mStartMs = 0;

    float   mStartPosX = 0, mStartPosY = 0, mStartPosZ = 0;
    int32_t mStartDimId = 0;

    std::vector<RecordPacketEntry> mEntryHeaders; // 仅供统计
    std::vector<std::pair<RecordPacketEntry, std::vector<uint8_t>>> mPackets;
    std::vector<std::pair<RecordPacketEntry, std::string>>          mChats;

    std::filesystem::path dataDir() const;
};

} // namespace hf_replay
