#include "Commands.h"

#include "Recorder.h"
#include "Replayer.h"

#include "ll/api/command/CommandHandle.h"
#include "ll/api/command/CommandRegistrar.h"

#include "mc/server/commands/CommandOrigin.h"
#include "mc/server/commands/CommandOutput.h"
#include "mc/server/commands/CommandPermissionLevel.h"
#include "mc/world/actor/Actor.h"
#include "mc/world/actor/ActorType.h"
#include "mc/world/actor/player/Player.h"

#include <algorithm>
#include <filesystem>
#include <vector>

namespace hf_replay {

static ::Player* originPlayer(::CommandOrigin const& origin) {
    auto* actor = origin.getEntity();
    if (!actor) return nullptr;
    if (!actor->isType(::ActorType::Player)) return nullptr;
    return static_cast<::Player*>(actor);
}

static std::vector<std::filesystem::path> listFiles() {
    std::vector<std::filesystem::path> files;
    std::error_code                    ec;
    auto                               dir = Recorder::recordsDir();
    if (!std::filesystem::exists(dir, ec)) return files;
    for (auto const& entry : std::filesystem::directory_iterator(dir, ec)) {
        if (entry.path().extension() == ".hfr") files.push_back(entry.path());
    }
    std::sort(files.begin(), files.end()); // 文件名含时间戳，字典序=时间序
    return files;
}

static void playFile(::CommandOutput& out, std::filesystem::path const& f) {
    auto err = Replayer::getInstance().start(f);
    if (!err.empty()) {
        out.error(err);
        return;
    }
    out.success("§a回放开始：{} §7假人已登场，停止用 /hf 4", f.stem().string());
}

struct HfNum {
    int num;
};

void registerCommands() {
    auto& cmd = ll::command::CommandRegistrar::getInstance().getOrCreateCommand(
        "hf", "假人行为录制回放", ::CommandPermissionLevel::GameDirectors);

    // /hf —— 显示用法
    cmd.overload().execute([](::CommandOrigin const&, ::CommandOutput& out) {
        out.success(
            "§6【假人回放】§r/hf 1 开始录制自己 | /hf 2 结束并保存 | /hf 3 回放最近一段 | "
            "/hf 3 <编号> 回放指定一段 | /hf 4 停止回放 | /hf 5 列表 | /hf 6 <编号> 删除");
    });

    // /hf 1 —— 录制自己
    cmd.overload().text("1").execute([](::CommandOrigin const& origin, ::CommandOutput& out) {
        auto* pl = originPlayer(origin);
        if (!pl) {
            out.error("这个命令必须由玩家在游戏里输入");
            return;
        }
        auto err = Recorder::getInstance().start(pl);
        if (!err.empty()) {
            out.error(err);
            return;
        }
        out.success("§a开始录制你自己的行为，去干你想干的事吧。完成了输入 /hf 2");
    });

    // /hf 2 —— 结束并保存
    cmd.overload().text("2").execute([](::CommandOrigin const&, ::CommandOutput& out) {
        auto r = Recorder::getInstance().stopAndSave();
        if (!r.ok) {
            out.error(r.msg);
            return;
        }
        out.success("§a录制完成，已保存为：{} §7现在输入 /hf 3 就能回放", r.msg);
    });

    // /hf 3 —— 回放最近一段
    cmd.overload().text("3").execute([](::CommandOrigin const&, ::CommandOutput& out) {
        auto files = listFiles();
        if (files.empty()) {
            out.error("还没有任何录制，先用 /hf 1 录一段");
            return;
        }
        playFile(out, files.back());
    });

    // /hf 3 <编号> —— 回放指定一段
    cmd.overload<HfNum>().text("3").required("num").execute(
        [](::CommandOrigin const&, ::CommandOutput& out, HfNum const& p) {
            auto files = listFiles();
            if (p.num < 1 || (size_t)p.num > files.size()) {
                out.error("编号 {} 不存在，用 /hf 5 查看列表", p.num);
                return;
            }
            playFile(out, files[(size_t)p.num - 1]);
        });

    // /hf 4 —— 停止回放并下线假人
    cmd.overload().text("4").execute([](::CommandOrigin const&, ::CommandOutput& out) {
        auto err = Replayer::getInstance().stop(true);
        if (!err.empty()) {
            out.error(err);
            return;
        }
        out.success("已停止回放，假人已下线");
    });

    // /hf 5 —— 列表
    cmd.overload().text("5").execute([](::CommandOrigin const&, ::CommandOutput& out) {
        auto files = listFiles();
        if (files.empty()) {
            out.success("还没有任何录制。用 /hf 1 开始第一段");
            return;
        }
        out.success("共 {} 段录制（§6{}§r 是最近一段）：", files.size(), files.back().stem().string());
        for (size_t i = 0; i < files.size(); ++i) {
            out.success("  {}. {}", i + 1, files[i].stem().string());
        }
    });

    // /hf 6 <编号> —— 删除
    cmd.overload<HfNum>().text("6").required("num").execute(
        [](::CommandOrigin const&, ::CommandOutput& out, HfNum const& p) {
            auto files = listFiles();
            if (p.num < 1 || (size_t)p.num > files.size()) {
                out.error("编号 {} 不存在，用 /hf 5 查看列表", p.num);
                return;
            }
            std::error_code ec;
            auto const&     f = files[(size_t)p.num - 1];
            if (!std::filesystem::remove(f, ec)) {
                out.error("删除失败：{}", f.stem().string());
                return;
            }
            out.success("已删除：{}", f.stem().string());
        });
}

} // namespace hf_replay
