════════════════════════════════════════════════════════════
 假人行为录制回放 · 原生版（hf-replay）构建与使用说明
════════════════════════════════════════════════════════════

【总架构 —— 你说的那个"复制粘贴"架构】

  录制：玩家发来的行为包（移动/跳/潜行/挖/放/攻击/挥手/换手持/
        聊天），一个字节都不解析，原样存文件。
        核心是 PlayerAuthInputPacket（协议144）：现代基岩版玩家
        每 tick 一条，位置朝向跳跃潜行冲刺挖方放方用物品全在里面。

  回放：创建假人 → 按原始时间戳，在服务端线程把原始字节
        原样灌回包对象，喂给 ServerNetworkHandler::handle()。
        服务端把假人当真玩家处理这些输入 —— 零翻译、零适配。

  为什么这样一定像：因为根本没有"驱动逻辑"。
  前两版死于驱动逻辑（寻路/纠偏/收敛），本版没有驱动逻辑可死。

────────────────────────────────────────────────
【游戏内命令】（只有数字，没有英文参数）
────────────────────────────────────────────────
  /hf            显示用法
  /hf 1          开始录制自己（谁输入录谁）
  /hf 2          结束录制并保存
  /hf 3          回放最近一段
  /hf 3 2        回放列表里的第 2 段
  /hf 4          停止回放、假人下线
  /hf 5          列出所有录制
  /hf 6 2        删除第 2 段

  权限：OP（GameDirectors）。

────────────────────────────────────────────────
【编译】（需要一台能上 github.com 的电脑）
────────────────────────────────────────────────
  标准环境：Windows + VS2022（勾选"C++ 桌面开发"负载）+ xmake
  （VS 装完后 xmake 会自动找到 MSVC；xmake 从 https://xmake.io 装）

  1. 装 xmake（https://xmake.io）和 VS2022（Windows）
  2. 本目录下执行：
       xmake f -m release -y
       xmake -y
     首次会自动下载 LeviLamina 26.20.* 及全部依赖，需联网。
  3. 产物在 bin/hf-replay/（hf-replay.dll + manifest.json）
  4. 把整个 hf-replay 文件夹丢进服务器的 mods/ 目录，重启。
     （简幻欢：放到 LeviLamina 的 mods 目录，和已装的原生 mod 同级）

  版本已锁：levilamina 26.20.*，对应你的 LeviLamina 26.20.3
  / BDS 1.26.20.5。若要换版本只改 xmake.lua 里的 add_requires。

────────────────────────────────────────────────
【编译期自查表】（本工程未实机编译过，以下是最可能报错的点，
  全部是"改一行"级别的问题，报错信息会直指行号）
────────────────────────────────────────────────
  1. Recorder.cpp 里 &ServerNetworkHandler::$handle
     → 若报"没有成员"，打开 mc/network/ServerNetworkHandler.h，
       找 handle(NetworkIdentifier const&, Packet const&) 的
       thunk 声明（$开头那个），替换名字即可。

  2. Recorder.cpp 里 stream.mBuffer
     → 若报错，改成 stream.mBuffer.get() 或 *stream.mBuffer
       （看 BinaryStream.h 里 mBuffer 是否包了 TypedStorage）。

  3. Replayer.cpp 里 ReadOnlyBinaryStream ros(e.data, false)
     → 构造签名若不同，看 BinaryStream.h 里 ReadOnlyBinaryStream
       的构造函数（可能是 (std::string_view, bool)），照着改。

  4. Commands.cpp 里 CommandRegistrar::getInstance()
     → 若要求参数，改成 getInstance(false)（false=服务端侧）。

  5. PlayerChatEvent::message() / ListenerBase::removeListener
     → 名称有出入就查 ll/api/event/player/PlayerChatEvent.h
       和 ll/api/event/ListenerBase.h。

  6. SimulatedPlayer::create(名字, 位置, 维度) 三参重载
     → 若不存在，改用六参版本：create(名字, 位置, 维度,
       getServerNetworkHandler(), "", std::nullopt)。

  7. 【运行期】若回放时假人站着不动（控制台不报错）：
       服务端可能丢弃"过期的输入 tick"。解决：在 Replayer.cpp
       的 step() 里 pkt->_read(ros) 之后，对 144 号包校正
       mClientTick（结构见 mc/network/packet/PlayerInputTick.h，
       成员是 mValue，自增即可）。v1 刻意没加，保持纯原样。

────────────────────────────────────────────────
【测试流程】（务必先拿一次性存档试！别拿正经存档）
────────────────────────────────────────────────
  1. 复制一份测试存档或新开一个世界
  2. 进游戏：/hf 1
  3. 走两步、跳一下、挖个方块、说句话
  4. /hf 2   →  提示保存路径
  5. /hf 3   →  假人在原地登场，原样重演刚才的一切
  6. /hf 4   →  假人下线
  出问题看服务器控制台：插件会打
  「回放开始/回放结束(完整|中断) 已重放 N 条」，
  把报错原样发回来即可定位。

────────────────────────────────────────────────
【已知边界】
────────────────────────────────────────────────
  · 聊天回放走 TextPacket 全服广播（和 LSE 的 talkAs 同管线），
    其他插件监听不到 ChatEvent（这是"原样重放"的边界）。
  · 攻击回放依赖 Interact(33)+Animate(40) 原样重放，
    打没打中由服务端命中判定决定，和真人一致。
  · 未收录的包类型（丢物、吃东西等独立包）v1 暂不回放，
    加白名单一行代码的事（Recorder.cpp 的 switch）。
════════════════════════════════════════════════════════════
